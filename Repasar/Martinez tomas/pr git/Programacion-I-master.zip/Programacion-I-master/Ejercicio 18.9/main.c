#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct
{
    int legajo;
    char nombre[50];
    float altura;
    int nota;
    char mail[50];
}laDireccion;




int main()
{

}
