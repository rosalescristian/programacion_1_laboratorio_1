#ifndef BIBLIOTECATOMAS_H_INCLUDED
#define BIBLIOTECATOMAS_H_INCLUDED

int getInt(char mensaje[]);
float getFloat(char mensaje[]);
char getChar(char mensaje[]);

char getNumeroAleatorio(int desde , int hasta , int iniciar);

#endif // BIBLIOTECATOMAS_H_INCLUDED
